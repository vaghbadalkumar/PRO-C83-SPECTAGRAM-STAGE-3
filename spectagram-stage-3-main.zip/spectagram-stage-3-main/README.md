# spectagram-stage-3
project solution for c83
